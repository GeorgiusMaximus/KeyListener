import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

import static java.awt.Color.GRAY;

public class MyFrame extends JFrame implements KeyListener {

    JLabel rocketLabel;
    ImageIcon image;
    JLabel enemy;

    public int enemyX;
    public int enemyY;
    public int playerSpeed = 10;
    public boolean gameOver = false;

    public MyFrame(){
        Random random = new Random();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("KeyListener");
        this.setSize(600, 400);
        this.setLocationRelativeTo(null);
        this.setLayout(null);
        this.addKeyListener(this);
        //this.getContentPane().setBackground(GRAY);
        //image = new ImageIcon("spaceRocket.png");

        enemy = new JLabel();
        enemy.setBounds(random.nextInt(10, 590), random.nextInt(10, 390), 64, 64);
        enemy.setBackground(Color.RED);
        enemy.setOpaque(true);

        rocketLabel = new JLabel();
        rocketLabel.setBounds(0, 0, 16, 16);
        //rocketLabel.setIcon(image);
        rocketLabel.setBackground(Color.BLACK);
        rocketLabel.setOpaque(true);
        //this.setIconImage(image.getImage());
        this.add(rocketLabel);
        this.add(enemy);
        this.setVisible(true);
        //checkCollisions();
        if (gameOver){
            System.exit(0);
        }
    }

    public void checkCollisions() {
        //doesn´t work
        if (rocketLabel.getX() == enemy.getY() && rocketLabel.getY() == enemy.getY()){
            gameOver = true;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
        switch (e.getKeyChar()){
            case 'a': rocketLabel.setLocation(rocketLabel.getX()- playerSpeed, rocketLabel.getY());
            break;
            case 'w': rocketLabel.setLocation(rocketLabel.getX(), rocketLabel.getY()- playerSpeed);
            break;
            case 's': rocketLabel.setLocation(rocketLabel.getX(), rocketLabel.getY()+ playerSpeed);
            break;
            case 'd': rocketLabel.setLocation(rocketLabel.getX()+ playerSpeed, rocketLabel.getY());
            break;
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()){
            case 37: rocketLabel.setLocation(rocketLabel.getX()- playerSpeed, rocketLabel.getY());
                break;
            case 38: rocketLabel.setLocation(rocketLabel.getX(), rocketLabel.getY()- playerSpeed);
                break;
            case 40: rocketLabel.setLocation(rocketLabel.getX(), rocketLabel.getY()+ playerSpeed);
                break;
            case 39: rocketLabel.setLocation(rocketLabel.getX()+ playerSpeed, rocketLabel.getY());
                break;
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {
        //System.out.println("You released Key-Character: " + e.getKeyChar());
        //System.out.println("You released Key-Code: " + e.getKeyCode());
    }
}
